///   <reference types = "cypress" />
describe('MENU - Ofertas de Compra e Venda - Nova Oferta:', () => {    
    it('CT01 - Efetuar Login:', () =>{
     // Dado que estou logado na plataforma merx.tech
     cy.visit('https://www.preprod.backoffice.merx.tech/');
     // Quando entro com CPF
     cy.get('input[name="username"').type('83579337009');
     // Quando clico no botão Próximo
     cy.contains('Próximo').click();
     // Quando entro com a senha
     cy.get('input[name="password"').type('qa@Mudar1');
     // Quando clico no botão entrar
     cy.contains('Entrar').click();
     cy.wait(3000);
     // Então valido o texto de saudação na área logada
     cy.contains('Olá, Commone User').should('be.visible');
     cy.wait(2000);
     //Quando clico no botão de menu
     cy.get('.sc-fzoyTs').click();
     //Quando clico no item de menu: Ofertas de Compra e Venda
     cy.get(':nth-child(2) > .MuiListItemText-root > .MuiTypography-root').click();
     //Quando clico no botão nova oferta
     cy.get('.MuiButton-contained > .MuiButton-label').click();
     //Quando seleciono o produto
     cy.get('#mui-component-select-product_id').click();
     cy.get('.MuiList-root > [tabindex="0"]').click();
     //Quando seleciono a modalidade
     cy.get('#mui-component-select-modality_id').click();
     cy.get('[data-value="0e3f84c8-7f87-478c-be6b-638d14f60fae"]').click();
     //Quando informo o preço
     cy.get(':nth-child(3) > :nth-child(1) > .sc-pzYib > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input').type('100');
     //Quando seleciono por
     cy.get('#mui-component-select-unit_of_measurement_id').click();
     cy.get('.MuiList-root > .MuiButtonBase-root').click();
     //Quando informo volume mínimo
     cy.get(':nth-child(4) > :nth-child(1) > .sc-pzYib > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input').type('100');
     //Quando informo volume máximo
     cy.get(':nth-child(2) > .sc-pzYib > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input').type('100000');
     //Quando selecino a safra
     cy.get('#mui-component-select-harvest_id').click();
     cy.get('[data-value="fc04585c-f23c-451c-8a22-c7b36aab886f"]').click();
     //Quando informo a data do pagamento
     cy.get('[style="margin-top: 10px; margin-bottom: 8px; width: 100%;"] > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input').click();
     cy.get(':nth-child(5) > :nth-child(7) > .MuiButtonBase-root > .MuiIconButton-label > .MuiTypography-root').click();
     cy.get('.MuiDialogActions-root > :nth-child(2) > .MuiButton-label').click();
     //Quando seleciono o tipo de pagamento
     cy.get('#mui-component-select-payment_type').click();
     cy.contains('Troca').click();
     //Quando seleciono a unidade
     cy.get('#mui-component-select-delivery_place').click();
     cy.get('.MuiList-root > [tabindex="-1"]').click();
     //Quando informo a data de expiração
     cy.get('[style="margin-top: 10px; padding-bottom: 8px;"] > :nth-child(1) > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input').click();
     cy.get(':nth-child(5) > :nth-child(7) > .MuiButtonBase-root > .MuiIconButton-label > .MuiTypography-root').click();
     cy.get('.MuiDialogActions-root > :nth-child(2) > .MuiButton-label').click();
     //Quando informo a hora de expiração
     cy.get('[style="margin-top: 10px; padding-bottom: 8px;"] > :nth-child(2) > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input').click();
     cy.get('.MuiPickersClock-squareMask').click();
     cy.get('.MuiDialogActions-root > :nth-child(2) > .MuiButton-label').click();
     //Quando descrevo a oferta
     cy.get(':nth-child(9) > .MuiGrid-root > .sc-pzYib > .MuiFormControl-root > .MuiInputBase-root').type('Criação de uma nova oferta');
     //Quando clico no botão criar
     cy.get('.MuiGrid-justify-xs-flex-end > .MuiButtonBase-root').click();
     //Então valido a mensagem de sucesso na tela de criação da nova oferta
     cy.get('#notistack-snackbar').should('be.visible');
    });
  });