///   <reference types = "cypress" />
describe('LOGIN:', () => {    
     it('CT01 - Efetuar Login:', () =>{
      // Dado que estou logado na plataforma merx.tech
      cy.visit('https://www.preprod.backoffice.merx.tech/');
      // Quando entro com CPF
      cy.get('input[name="username"').type('83579337009');
      // Quando clico no botão Próximo
      cy.contains('Próximo').click();
      // Quando entro com a senha
      cy.get('input[name="password"').type('qa@Mudar1');
      // Quando clico no botão entrar
      cy.contains('Entrar').click();
      cy.wait(3000);
      // Então valido o texto de saudação na área logada
      cy.contains('Olá, Commone User').should('be.visible');
     });
   });