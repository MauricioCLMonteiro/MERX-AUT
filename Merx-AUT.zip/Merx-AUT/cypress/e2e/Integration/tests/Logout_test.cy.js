///   <reference types = "cypress" />
describe('LOGOUT:', () => {    
  it('CT01 - Efetuar Logout:', () =>{
   // Dado que estou logado na plataforma merx.tech
   cy.visit('https://www.preprod.backoffice.merx.tech/');
   // Quando entro com CPF
   cy.get('input[name="username"').type('83579337009');
   // Quando clico no botão Próximo
   cy.contains('Próximo').click();
   // Quando entro com a senha
   cy.get('input[name="password"').type('qa@Mudar1');
   // Quando clico no botão entrar
   cy.contains('Entrar').click();
   cy.wait(3000);
   // Então valido o texto de saudação na área logada
   cy.contains('Olá, Commone User').should('be.visible');
   //Quando clico no botão de menu
   cy.get('.sc-fzoyTs').click();
   //Quando clico no item logout
   cy.get(':nth-child(12) > .MuiListItemText-root > .MuiTypography-root').click();
   // Então valido que estou novamente na área de login
   cy.get('.sc-fzozJi').should('be.visible');
  });
});